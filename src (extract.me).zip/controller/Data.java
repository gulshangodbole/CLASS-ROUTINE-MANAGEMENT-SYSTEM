/*
* Provides complete information necessary for Time Table Scheduling
* 1. Rooms
* 2. Courses
* 3. Teachers
* 4. Subject
* 5. Time Slot
*/
package controller;

import dataset.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class Data {
    private ArrayList<Room> rooms;
    private ArrayList<Subject> subjects, theory, labs;
    private ArrayList<Teacher> teachers;
    private ArrayList<Course> courses;
    private ArrayList<TimeSlot> time_slots;
    private int numberOfCourse = 0;

    public Data() { initialize(); }

    private Data initialize() {

        //Initializing Rooms
        Room room1 = new Room("UG413", "", 100);
        Room room2 = new Room("UG423", "", 100);
        Room room3 = new Room("UG433", "", 100);
        Room room4 = new Room("LAB1", "", 100);
        Room room5 = new Room("LAB2", "", 100);
        Room room6 = new Room("LAB3", "", 100);
        rooms = new ArrayList<>(Arrays.asList(room1, room2, room3, room4, room5, room6));

        //Initializing Teachers
        Teacher teacher1 = new Teacher("IB", "Prof. Indrajeet Banerjee", 9, 17);
        Teacher teacher2 = new Teacher("PG", "Prof. Prasun Ghoshal", 9, 17);
        Teacher teacher3 = new Teacher("CG", "Prof. Chandan Giri", 9, 17);
        Teacher teacher4 = new Teacher("SD", "Prof. Sukanta Das", 9, 17);
        Teacher teacher5 = new Teacher("SK", "Prof. Shyamlendu Kandar", 9, 17);
        Teacher teacher6 = new Teacher("AB", "Prof. Arindam Biswas", 9, 17);
        Teacher teacher7 = new Teacher("HR", "Prof. Hafizur Rahman", 9, 17);
        Teacher teacher8 = new Teacher("RN", "Prof. Ruchira Naskar", 9, 17);
        Teacher teacher9 = new Teacher("SR", "Prof. Surojit Kumar Roy", 9, 17);
        Teacher teacher10 = new Teacher("SPM", "Prof. Santi Prasad Maity", 9, 17);
        Teacher teacher11 = new Teacher("TS", "Prof. Tuhina Samanta", 9, 17);
        Teacher teacher12 = new Teacher("SB", "Prof. Shubhashish Bhaumik", 9, 17);
        Teacher teacher13 = new Teacher("PSR", "Prof. Partha Sarthi Roy", 9, 17);

        teachers = new ArrayList<>(Arrays.asList(teacher1, teacher2, teacher3, teacher4, teacher5, teacher6,
                                   teacher7, teacher8, teacher9, teacher10, teacher11,teacher12,teacher13));

        //Initializing Subjects
        Subject subject1 = new Subject("IT-2201", "Communication System", teacher11, 3, 0, 0);
        Subject subject2 = new Subject("IT-2202", "Computer Organization and Architecture", teacher2, 4, 0, 0);
        Subject subject3 = new Subject("IT-2203", "Computer Graphics", teacher1, 3, 0, 0);
        Subject subject4 = new Subject("IT-2204", "Formal Language and Automata Theory", teacher5, 3, 0, 0);
        Subject subject5 = new Subject("IT-2205", "Object Oriented System Design", teacher5, 3, 0, 0);
        Subject subject15 = new Subject("IT-2271", "Communication System", teacher11, 0, 0, 3);
        Subject subject20 = new Subject("IT-2272", "Computer Organization and Architecture", teacher2, 0, 0, 3);
        Subject subject19 = new Subject("IT-2273", "Computer Graphics", teacher1, 0, 0, 3);

        
        Subject subject6 = new Subject("IT-601", "Analysis and Design of Algorithm", teacher4, 4, 0, 0);
        Subject subject7 = new Subject("IT-602", "Compiler Design", teacher5, 3, 0, 0);
        Subject subject8 = new Subject("IT-603", "Computer Networks", teacher6, 4, 0, 0);
        Subject subject9 = new Subject("IT-621/1", "System Programming", teacher7, 3, 0, 0);
        Subject subject10 = new Subject("HU-5601", "Economics", teacher12, 2, 0, 0);
        Subject subject16 = new Subject("IT-671", "Analysis and Design of Algorithm", teacher4, 0, 0, 3);
        Subject subject17 = new Subject("IT-672", "Compiler Design", teacher5, 0, 0, 3);
        Subject subject18 = new Subject("IT-673", "Computer Networks", teacher6, 0, 0, 3);


        Subject subject11 = new Subject("IT-801", "Information and System Security", teacher8, 4, 0, 0);
        Subject subject12 = new Subject("IT-802", "Artificial Intelligence", teacher9, 3, 0, 0);
        Subject subject13 = new Subject("IT-803", "Image Processing and Pattern Recognition", teacher10, 3, 0, 0);
        Subject subject14 = new Subject("HU-7801", "Accounting and Financial Management", teacher13, 2, 0, 0);
        Subject subject21 = new Subject("IT-871", "Information and System Security", teacher8, 0, 0, 3);
        Subject subject22 = new Subject("IT-873", "Image Processing and Pattern Recognition", teacher10, 0, 0, 3);

     
        subjects = new ArrayList<>(Arrays.asList(subject1, subject2, subject3, subject4, subject5, subject6,
                                   subject7, subject8, subject9, subject10, subject11, subject12,
                                   subject13, subject14,subject15,subject16,subject18,subject17,subject19,subject20,subject21,subject22));
        
        //Initializing Course

        theory = new ArrayList<>(Arrays.asList(subject1, subject2, subject3, subject4, subject5));
        labs = new ArrayList<>(Arrays.asList(subject15,subject19,subject20));
        Collections.shuffle(theory);
        Collections.shuffle(labs);
        theory.addAll(labs);
        //Initializing Course
        Course course1 = new Course("UG2", "B.Tech 4th sem", theory, 100);

        theory = new ArrayList<>(Arrays.asList(subject6, subject7, subject8, subject9, subject10));
        labs = new ArrayList<>(Arrays.asList(subject16,subject17,subject18));
        Collections.shuffle(theory);
        Collections.shuffle(labs);
        theory.addAll(labs);

        Course course2 = new Course("UG3", "B.Tech 6th sem", theory, 100);

        theory = new ArrayList<>(Arrays.asList(subject11, subject12, subject13, subject14));
        labs = new ArrayList<>(Arrays.asList(subject21,subject22));
        Collections.shuffle(theory);
        Collections.shuffle(labs);
        theory.addAll(labs);
        
        Course course3 = new Course("UG4", "B.Tech 8th sem", theory, 100);

        courses = new ArrayList<>(Arrays.asList(course1, course2, course3));

        TimeSlot time1 = new TimeSlot("Mo1", 9, 10, "Monday");
        TimeSlot time2 = new TimeSlot("Tu1", 9, 10, "Tuesday");
        TimeSlot time3 = new TimeSlot("We1", 9, 10, "Wednesday");
        TimeSlot time4 = new TimeSlot("Th1", 9, 10, "Thrusday");
        TimeSlot time5 = new TimeSlot("Fr1", 9, 10, "Friday");
        time_slots = new ArrayList<>(Arrays.asList(time1, time2, time3, time4, time5));
        time1 = new TimeSlot("Mo2", 10, 11, "Monday");
        time2 = new TimeSlot("Tu2", 10, 11, "Tuesday");
        time3 = new TimeSlot("We2", 10, 11, "Wednesday");
        time4 = new TimeSlot("Th2", 10, 11, "Thrusday");
        time5 = new TimeSlot("Fr2", 10, 11, "Friday");
        time_slots.addAll(Arrays.asList(time1, time2, time3, time4, time5));
        time1 = new TimeSlot("Mo3", 11, 12, "Monday");
        time2 = new TimeSlot("Tu3", 11, 12, "Tuesday");
        time3 = new TimeSlot("We3", 11, 12, "Wednesday");
        time4 = new TimeSlot("Th3", 11, 12, "Thrusday");
        time5 = new TimeSlot("Fr3", 11, 12, "Friday");
        time_slots.addAll(Arrays.asList(time1, time2, time3, time4, time5));
        time1 = new TimeSlot("Mo4", 12, 13, "Monday");
        time2 = new TimeSlot("Tu4", 12, 13, "Tuesday");
        time3 = new TimeSlot("We4", 12, 13, "Wednesday");
        time4 = new TimeSlot("Th4", 12, 13, "Thrusday");
        time5 = new TimeSlot("Fr4", 12, 13, "Friday");
        time_slots.addAll(Arrays.asList(time1, time2, time3, time4, time5));
        time1 = new TimeSlot("Mo5", 14, 17, "Monday");
        time2 = new TimeSlot("Tu5", 14, 17, "Tuesday");
        time3 = new TimeSlot("We5", 14, 17, "Wednesday");
        time4 = new TimeSlot("Th5", 14, 17, "Thrusday");
        time5 = new TimeSlot("Fr5", 14, 17, "Friday");
        time_slots.addAll(Arrays.asList(time1, time2, time3, time4, time5));
        // time1 = new TimeSlot("Mo6", 15, 16, "Monday");
        // time2 = new TimeSlot("Tu6", 15, 16, "Tuesday");
        // time3 = new TimeSlot("We6", 15, 16, "Wednesday");
        // time4 = new TimeSlot("Th6", 15, 16, "Thursday");
        // time5 = new TimeSlot("Fr6", 15, 16, "Friday");
        // time_slots.addAll(Arrays.asList(time1, time2, time3, time4, time5));
        // time1 = new TimeSlot("Mo7", 16, 17, "Monday");
        // time2 = new TimeSlot("Tu7", 16, 17, "Tuesday");
        // time3 = new TimeSlot("We7", 16, 17, "Wednesday");
        // time4 = new TimeSlot("Th7", 16, 17, "Thrusday");
        // time5 = new TimeSlot("Fr7", 16, 17, "Friday");
        // time_slots.addAll(Arrays.asList(time1, time2, time3, time4, time5));

        numberOfCourse = courses.size();

        return this;
    }

    public ArrayList<Room> getRooms() { return rooms; }
    public ArrayList<Subject> getSubjects() { return subjects; }
    public ArrayList<Teacher> getTeachers() { return teachers; }
    public ArrayList<Course> getCourses() { return courses; }
    public ArrayList<TimeSlot> getTimeSlots() { return time_slots; }
    public int getNumberOfCourse() { return numberOfCourse; }

}
